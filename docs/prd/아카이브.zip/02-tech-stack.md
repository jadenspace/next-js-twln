# 02. 기술 스택 & 아키텍처

## 🛠️ 기술 스택 개요

```
┌─────────────────────────────────────────────────────────┐
│                    Frontend Layer                        │
│  Next.js 15 (App Router) + React 19 + TypeScript        │
│  Tailwind CSS v4 + shadcn/ui                            │
│  TanStack Query (서버 상태) + Zustand (클라이언트 상태)   │
└─────────────────────────────────────────────────────────┘
                            │
┌─────────────────────────────────────────────────────────┐
│                    Backend Layer                         │
│  Next.js API Routes + Supabase                          │
│  PostgreSQL + Row Level Security                         │
└─────────────────────────────────────────────────────────┘
                            │
┌─────────────────────────────────────────────────────────┐
│                    Infrastructure                        │
│  Vercel (호스팅 + Cron) + Supabase (DB + Auth)          │
└─────────────────────────────────────────────────────────┘
```

---

## 📦 주요 의존성

### Core
| 패키지 | 버전 | 용도 | 바이브코딩 친화도 |
|-------|-----|-----|----------------|
| `next` | 16.0.10 | 프레임워크 | ⭐⭐⭐⭐⭐ |
| `react` | 19.2.0 | UI 라이브러리 | ⭐⭐⭐⭐⭐ |
| `typescript` | 5.9.3 | 타입 안전성 | ⭐⭐⭐⭐⭐ |

### Backend & Data
| 패키지 | 용도 | 선택 이유 |
|-------|-----|---------|
| `@supabase/ssr` | SSR 인증 | Next.js App Router 최적화 |
| `@supabase/supabase-js` | DB/Auth 클라이언트 | 풀스택 통합 |
| `@tanstack/react-query` | 서버 상태 관리 | 캐싱, 재시도, 자동 리페치 |
| `zustand` | 클라이언트 상태 | 간단한 API, 보일러플레이트 적음 |

### UI
| 패키지 | 용도 |
|-------|-----|
| `tailwindcss` v4 | 스타일링 |
| `shadcn/ui` | 컴포넌트 라이브러리 |
| `lucide-react` | 아이콘 |
| `sonner` | 토스트 알림 |

### 3D & Animation
| 패키지 | 용도 |
|-------|-----|
| `three` | 3D 렌더링 |
| `@react-three/fiber` | React Three.js 바인딩 |
| `@react-three/drei` | Three.js 헬퍼 |
| `@react-three/rapier` | 물리 엔진 |

---

## 🏗️ FSD 아키텍처 (Feature Sliced Design)

### 왜 FSD인가?
1. **AI 친화적**: 명확한 폴더 구조로 AI가 파일 위치 파악 용이
2. **독립적 기능**: 기능별 분리로 side effect 최소화
3. **확장성**: 새 기능 추가가 기존 코드에 영향 적음

### 레이어 구조

```
src/
├── app/                  # Next.js App Router (라우팅)
│   ├── (dashboard)/      # 인증 필요 페이지 그룹
│   ├── api/              # API Routes
│   ├── login/            # 공개 페이지
│   └── layout.tsx        # 루트 레이아웃
│
├── features/             # 비즈니스 기능
│   ├── auth/             # 인증 관련
│   ├── lotto/            # 로또 분석/생성
│   ├── points/           # 포인트 시스템
│   ├── payments/         # 결제
│   └── gamification/     # 게이미피케이션
│
├── entities/             # 핵심 엔티티
│   └── user/             # 사용자 모델
│
└── shared/               # 공통 유틸리티
    ├── ui/               # shadcn/ui 컴포넌트
    ├── lib/              # 유틸 함수, Supabase 클라이언트
    ├── components/       # 공통 컴포넌트
    └── types/            # 공통 타입
```

### 레이어 규칙 (임포트 방향)
```
app → features → entities → shared
         ↓           ↓          ↓
       (상위 레이어는 하위 레이어만 임포트 가능)
```

---

## 🔐 상태 관리 전략

### TanStack Query (서버 상태)
```typescript
// 서버에서 가져오는 데이터
const { data: lottoDraws } = useQuery({
  queryKey: ['lotto', 'draws'],
  queryFn: fetchLottoDraws,
});
```

**사용 케이스**:
- 로또 당첨 번호 조회
- 사용자 정보 조회
- 포인트 조회

### Zustand (클라이언트 상태)
```typescript
// 브라우저에서만 사용하는 상태
const useAuthStore = create((set) => ({
  user: null,
  setUser: (user) => set({ user }),
}));
```

**사용 케이스**:
- 현재 로그인 유저
- UI 상태 (모달, 사이드바)
- 임시 선택값

---

## 🔧 바이브코딩 팁

### 기술 스택 선택 시
- ✅ AI가 학습 데이터가 많은 스택 선택 (Next.js, React)
- ✅ 공식 문서가 잘 되어있는 것 (Supabase, TanStack Query)
- ✅ 보일러플레이트 적은 것 (Zustand > Redux)

### AI에게 구조 설명할 때
```
프로젝트는 FSD 아키텍처를 따라.
- src/features/lotto/에 로또 관련 로직
- src/shared/ui/에 shadcn 컴포넌트
- src/app/api/에 API 라우트

새 기능은 features 폴더에 추가해줘.
```

### 피해야 할 패턴
- ❌ 한 파일에 너무 많은 코드 (AI 컨텍스트 초과)
- ❌ 순환 임포트 (FSD 규칙 위반)
- ❌ 타입 정의 없이 진행 (나중에 수정 어려움)

### 실패했던 시도
```
# 이렇게 하면 안 됨
"상태 관리 알아서 해줘" → Redux, Context, useState 섞여서 혼란

# 이렇게 해야 함
"서버 데이터는 TanStack Query로, 클라이언트 상태는 Zustand로 구현해"
```
